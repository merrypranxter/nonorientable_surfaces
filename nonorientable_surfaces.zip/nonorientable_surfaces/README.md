# nonorientable_surfaces

> Möbius strips, Klein bottles, and surfaces that have no "outside."

## What This Is

Most surfaces are orientable: they have two distinct sides (inside/outside). **Non-orientable surfaces** do not. If you walk along a Möbius strip, you return to your starting point mirror-reversed.

This repo visualizes:
- **Möbius strip** — one-sided, one-edged
- **Klein bottle** — no inside or outside, no edges
- **Real projective plane** — every pair of lines intersects
- **Boy's surface** — immersion of RP² in 3D (self-intersecting)

## Key Properties

| Surface | Euler χ | Orientable? | Boundary? |
|---------|---------|-------------|-----------|
| Möbius strip | 0 | No | Yes (1 circle) |
| Klein bottle | 0 | No | No |
| Real projective plane | 1 | No | No |
| Boy's surface | 1 | No | No (immersion) |

## Visual Approaches

### 1. Parametric Surfaces
Classic parametric equations, rendered with normal mapping.

### 2. Texture Tracking
Show how textures wrap "wrong" — a right-handed arrow becomes left-handed.

### 3. Cut-and-Fold
Animate the construction: rectangle → twist → glue.

### 4. 4D Rotation
Klein bottle properly lives in 4D. Rotate through the 4th dimension.

## Note: Klein Bottle in 3D
A true Klein bottle cannot be embedded in 3D without self-intersection. All 3D visualizations are either:
- **Immersions** (self-intersecting, like Boy's surface)
- **Truncated** (cut open to avoid intersection)
- **4D projections** (rotate through 4D, project to 3D)

## Related

- `kleinian_groups` — completely different! That's complex dynamics / limit sets
- `hopf_fibration` — shared fiber bundle topology

---

*There is no inside. There is no outside. There is only the surface, and it goes on forever.*
